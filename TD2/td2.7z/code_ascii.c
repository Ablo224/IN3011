#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
	char code;
	printf("Entré le caractère: ");
	scanf("%c",&code);
	printf("\n%d code ASCII de %c\n",code,code);
	
	return 0;
}
